#Ruby Practice Exercise #5
#------------------------------------------------------------------
# first method
#------------------------------------------------------------------
# def draw(height, width, outside_letter, inside_letter)
#   1.upto(height) do |row|
#     if row == 1
#       puts outside_letter * width 
#     elsif row == height 
#       puts  outside_letter * width 
#     elsif
#        # middle = inside_letter * (width - 2)
#        # puts "#{outside_letter}#{middle}#{outside_letter}"  	
# 	for i in 1..height - 2 do
# 		print "|"
# 		for i in 1...width -1 do
# 		print " " 
# 			end
# 			print "|\n" 
# 			end	
# 		end
# 	end
# end

# draw(4, 4, "-", " ")

#------------------------------------------------------------------
# second method 
#------------------------------------------------------------------
class DrawBox
	def initialize(height,width,outside,inside)
		@height = height
		@width = width
		@outside = outside
		@inside = inside
	end
	def draw(ender = "-")
		1.upto(@height) do |row|
			if row == 1
		ende = ender * @width
			puts "#{@outside}#{ende}#{@outside}"
		elsif row == @height
		ende = ender * @width
			puts "#{@outside}#{ende}#{@outside}"
		else
		middle = @inside * @width
			puts "#{@outside}#{middle}#{@outside}"
			end
		end
	end
end

cube = DrawBox.new(4,4,"|"," ")
cube.draw("-")



