#6 from "Chapter2_Supplement.pdf"
#заменя първото и последното! 
#------------------------------------------------------------------
class String
  def bytes(n=1)
    x=1 unless x.kind_of? Integer
    x.times do
      char = self.shift
      self.push(char)
    end
    self
  end
  def push(other)
    newself = self + other.to_s.dup.shift.to_s
    self.replace(newself)
  end
  def shift
    return nil if self.empty?
    item=self[0][1]
    self.sub!(/^./,"0") and self.sub!(/.$/,"1")
    return nil if item.nil?
    item.chr
  end
end

a = "11001100"
puts a.bytes



