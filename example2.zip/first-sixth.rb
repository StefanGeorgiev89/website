#------------------------------------------------------------------
#3-i from email
#------------------------------------------------------------------
def set_bit(num, value, position)
	return num |= value << position;
end
def clear_bit(num, value, position)
	return num &= ~(value << position);
end
#puts set_bit(3,3,3)
#puts clear_bit(2,1,1)

#------------------------------------------------------------------
#3-ii from email
#------------------------------------------------------------------
class String
	def convert_base(from, to)
		self.to_i(from).to_s(to)
	end
end

#p '23'.convert_base(2,16)

#------------------------------------------------------------------
#3-iii from email
#------------------------------------------------------------------
def bitcount(x)
	 count = 0 
	while x  != 0 
    	x &= (x-1)
    	count +=1
	end
	return count
end
#puts bitcount(1110)

#------------------------------------------------------------------
#3-iv from email 
#------------------------------------------------------------------   
def check(arg)	
	if arg & 2 == 0
		return true
	else false
	end
end
#puts check(13)

#------------------------------------------------------------------
#3-v from email
#------------------------------------------------------------------
puts "a = 5" 
puts "b = 6"
a = 5
b = 6
puts "after"
a = a ^ b
b = b ^ a
a = a ^ b

puts "a = #{a}"
puts "b = #{b}"

