puts 'hello'
print 1+1