#1# first example
$arr = {
"Paul Barry"=> ["Programming", "Networking", "Security", "Open Source", "Frameworks"],
"Chris Meudec" =>["Testing", "Safety Systems", "Formal Systems", "Programming Languages"],
"Nigel Whyte" => ["Graphics", "Imaging", "Programming", "Sign Language", "Trees"],
"Austin Kinsella" => ["Networks", "WANs", "Programming", "Macintosh", "Digital Photography"],
"Garry Moloney"=> ["Placement", "Employment", "Emerging Systems", "Web Development"],
"Charles Neuman" => ["Control Systems", "Teaching", "Robotics", "Feedback Loops"],
"Geri Ilieva" => ["Star Wars", "Cooking", "Photography", "Programming"],
"Anthony Rowe" => ["Real-time Embedded Systems", "Energy-efficient Solutions", "Programming", "DroneResearch"]
}
#1
def lector_name(name)
  puts $arr
end
#puts lector_name("Paul Barry")
#--------------------------------------------
#2
def second(name)
	return 
		$arr[name][1]
		$arr[name][3]
end
#--------------------------------------------
#3
def foruth(name)
	puts $arr[name][3]
end
def replace_word(n)
#puts foruth("Anthony Rowe")
#--------------------------------------------
#4
  n.each do |a|
    i = 0
    if s.eql? "Programming"
      n[i] = "Software Engineering"
    end
    i += 1
  end
end
puts 

def replace_programming
  $arr.each_value{|val| replace_word(val)} 
end
#replace_programming
#$arr
#-------------------------/
#To given key
# def replace_element(key)
# 	$arr[key].instance_eval {insert(index("Programming"), "Software Engineering")}
# 	$arr[key].delete("Programming")
# end
# replace_element("Paul Barry")
# puts $arr
#--------------------------------------------
#5 
def sorting(n)
  n.sort!{|x,y| x<=>y}
end

def sort_hash
   $arr.each_value{|val| sorting(val)}
end
#sort_hash
#puts $arr
#--------------------------------------------
#6
def replace_two(n)
   a = 0
   n.each do
     a += 1
   end
   prom = ""
   prom = n[0]
   n[0] = n[a - 1]
   n[a - 1] = prom
end
 
def replace_last
   $arr.each_value{|val| replace_two(val)}
end

replace_last
$arr.each{|x, y| puts "#{x}: #{y}"}
