#2# second example
#2.1 - първи начин
puts " 9C 01 00 5F 2A 02 07 52 C3 01 00 9F 02 06 00 00 00 00 20 00 9A 03 17 03 24 9F 21 03 12 05 24".gsub(' ', '')

#2.2 - втори начин
puts "Input"
num = gets.chomp

puts num.gsub(/\s+/, '')