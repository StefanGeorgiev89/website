#3# third sample
textfile = File.new("txet.txt", "w+")
File.new("text.txt").each_line.reverse_each { |line|
    textfile.puts line 
}
textfile.close


#Insert: your text in text.txt
#Output: creat new text file => txet.txt
